# Skyblock RPG Changelogs

<!-- Added, Fixed, Removed, Modified, Deprecated, Buggy !-->

## Skyblock RPG InDev 0.0.2 => The Terminal Update
### Added Features
* **Terminal** Added
* **Terminal Commands** Added
* Crash Report Log Added
* **Game Menu** Added
* **Location Handler** Added
* **Graveyard Zombie Fight** Added
* **Mining Power** Added
* **Axe Power** Added
* **Game Credits** Added
### Fixed
* Title Screen Fixed (ASCII Art Added)


## Skyblock RPG InDev 0.0.1 => The Tutorial Island Update
### Added Features
* Game Added:
 * Skyblock RPG.bat Added
 * *saves* and *scripts* folders Added
 * **Command Help Utilitary** Added
 * loadGame.cmd Added (*loading saves script*)
 * save.cmd Added (*saves current variables in a .sav file*)
 * setupNewGame.cmd Added (*generates all game variables and sets them to their normal values*)
 * **Errors**:
   * error001 -> *prevents the player to launch any script other than the game one*
   * error002 -> *handles location critical variable errors in the setupNewGame.cmd script*
 * **Tutorial Island** Added (*islandBeginning.cmd*)
 * **Encyclopaedia GUI** Added
 
### Fixed
* SKY-001: When no username is provided, the game automatically picks the current session username.
 * Now, if a player doesn't provide a username, the game will give a name from the followings: Apple, Banana, Coconut, Durian. If the player has those four usernames, he'll be obligated to provide a username.
 
### Deprecated
 * Title Screen Deprecated (ASCII ART coming soon)